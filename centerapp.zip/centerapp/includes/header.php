<?php
session_start();
require_once 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location:login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <header>
        
        <h2 class="title2">نظام إدارة المركز التعليمي</h2>

        <div class="user-info">
            <span>مرحبًا، <?php echo $_SESSION['username']; ?></span>
            <a href="../logout.php" class="logout-btn">تسجيل الخروج</a>
        </div>
    </header>
