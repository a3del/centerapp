</main> <!-- إغلاق الـ main-content -->
<footer>
    <p>&copy; <?php echo date("Y"); ?> جميع الحقوق محفوظة لمركز التعليمي.</p>
</footer>
</body>
</html>
