<aside class="sidebar">
    <ul>
        <li><a href="dashboard.php">الرئيسية</a></li>
        <li><a href="students.php">إدارة الطلاب</a></li>
        <li><a href="teachers.php">إدارة المدرسين</a></li>
        <li><a href="branches.php">إدارة الفروع</a></li>
        <li><a href="finance.php">الحسابات والتقارير</a></li>
        <li><a href="student_expenses.php">مصاريف الطلاب</a></li>
        <li><a href="users.php">إدارة المستخدمين</a></li>
    </ul>
</aside>
<main class="main-content">
